package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.sql.DataSource;

import vo.ProfessorInfo;
import vo.StudentInfo;
import vo.SubjectInfo;

public class SubjectInfoDao {
	DataSource ds;

	public void setDataSource(DataSource ds) {
		this.ds = ds;
	}

	public int insert(SubjectInfo subjectInfo) throws Exception  {
		Connection connection = null;
		PreparedStatement stmt = null;

		try {
			connection = ds.getConnection();
			stmt = connection.prepareStatement(
					"INSERT INTO SUBJECT_INFO(SUBJ_NAME,SUBJ_OUTLINE,SUBJ_IMAGE,SUBJ_CODE_DIV,LIMIT_NUM,REGIST_CODE,SUBJ_CRE_DATE,SUBJ_MOD_DATE)"
							+ " VALUES (?,?,?,?,?,?,NOW(),NOW())");
			stmt.setString(1, subjectInfo.getSubj_name());
			stmt.setString(2, subjectInfo.getSubj_outline());
			stmt.setString(3, subjectInfo.getSubj_image());
			stmt.setString(4, subjectInfo.getSubj_code_div());
			stmt.setInt(5, subjectInfo.getLimit_num());
			stmt.setString(6, subjectInfo.getRegist_code());
			return stmt.executeUpdate();

		} catch (Exception e) {
			throw e;

		} finally {
			try {if (stmt != null) stmt.close();} catch(Exception e) {}
			try {if (connection != null) connection.close();} catch(Exception e) {}
		}
	}

	public List<String> selectSubject(ArrayList<String> list) throws Exception {
		Connection connection = null;
		Statement stmt = null;
		ResultSet rs = null;

		ArrayList<String> subjectList= list;
		ArrayList<String> subjectSelect = new ArrayList<String>();

		Iterator<String> iterator = subjectList.iterator();


		try {
			connection = ds.getConnection();

			stmt = connection.createStatement();
			rs = stmt.executeQuery(
					"SELECT SUBJ_CODE_DIV FROM SUBJECT_INFO");


			// 입력한 과목코드와 DB의 과목코드를 비교하여 맞는것만 리턴
			while(rs.next()) {
				while( iterator.hasNext() )
				{
					if(rs.getString("SUBJ_CODE_DIV").equals(iterator.next())) {
						subjectSelect.add(rs.getString("SUBJ_CODE_DIV"));
					}
				}	
			}
			return subjectSelect;

		} catch ( Exception e) {
			throw e;

		}  finally {
			try {if (stmt != null) stmt.close();} catch(Exception e) {}
			try {if (connection != null) connection.close();} catch(Exception e) {}
			try {if (rs != null) rs.close();} catch(Exception e) {}
		}

	}


	// 로그인 후 메인화면에 듣고있는 과목정보를 가져온다.
	public SubjectInfo getSubjInfo(StudentInfo stdInfo) throws Exception {
		Connection connection = null;
		Statement stmt = null;
		ResultSet rs = null;

		int stdId = stdInfo.getStdId();
		SubjectInfo subjectInfo = null;
		try {
			connection = ds.getConnection();

			stmt = connection.createStatement();
			rs = stmt.executeQuery(
					"SELECT SUBJ_CODE_DIV, SUBJ_NAME, SUBJ_IMAGE FROM SUBJECT_INFO WHERE SUBJ_CODE_DIV="+stdId);


			while(rs.next()) {
				subjectInfo = new SubjectInfo()
						.setSubj_code_div(rs.getString("SUBJ_CODE_DIV"))
						.setSubj_name(rs.getString("SUBJ_NAME"))
						.setSubj_image(rs.getString("SUBJ_IMAGE"));

			}


			return subjectInfo;	

		} catch ( Exception e) {
			throw e;

		}  finally {
			try {if (stmt != null) stmt.close();} catch(Exception e) {}
			try {if (connection != null) connection.close();} catch(Exception e) {}
			try {if (rs != null) rs.close();} catch(Exception e) {}
		}

	}

	// 이게 이름같고 파라미터 달라도 상관없낭 ???
	// 로그인 후 메인화면에 듣고있는 과목정보를 가져온다.
	public SubjectInfo getSubjInfo(ProfessorInfo profInfo) throws Exception {
		Connection connection = null;
		Statement stmt = null;
		ResultSet rs = null;

		int profId = profInfo.getProfId();
		SubjectInfo subjectInfo = null;
		try {
			connection = ds.getConnection();

			stmt = connection.createStatement();
			rs = stmt.executeQuery(
					"SELECT SUBJ_CODE_DIV, SUBJ_NAME, SUBJ_IMAGE FROM SUBJECT_INFO WHERE SUBJ_CODE_DIV="+profId);


			while(rs.next()) {
				subjectInfo = new SubjectInfo()
						.setSubj_code_div(rs.getString("SUBJ_CODE_DIV"))
						.setSubj_name(rs.getString("SUBJ_NAME"))
						.setSubj_image(rs.getString("SUBJ_IMAGE"));

			}


			return subjectInfo;	

		} catch ( Exception e) {
			throw e;

		}  finally {
			try {if (stmt != null) stmt.close();} catch(Exception e) {}
			try {if (connection != null) connection.close();} catch(Exception e) {}
			try {if (rs != null) rs.close();} catch(Exception e) {}
		}

	}

}
