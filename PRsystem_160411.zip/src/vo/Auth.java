package vo;


public class Auth {
	protected String 		auth;

	public String getAuth() {
		return auth;
	}
	public Auth setAuth(String auth) {
		this.auth = auth;
		return this;
	}
}
