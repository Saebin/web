package servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.ProfessorInfoDao;
import dao.StudentInfoDao;
import dao.SubjectInfoDao;
import vo.Auth;
import vo.ProfessorInfo;
import vo.StudentInfo;
import vo.SubjectInfo;

@WebServlet("/main")
public class MainServlet extends HttpServlet{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public void doGet(
			HttpServletRequest request, HttpServletResponse response)
					throws ServletException, IOException {
		try {
			ServletContext sc = this.getServletContext();

			HttpSession session = (HttpSession) request.getSession();
			Auth auth = (Auth) session.getAttribute("auth");



			if(auth == null) {

				response.sendRedirect("login");

			} else {

				if(auth.getAuth().equals("student")) {

					StudentInfoDao stdInfoDao = (StudentInfoDao)sc.getAttribute("stdInfoDao");
					//				request.setAttribute("stdInfo", stdInfoDao.selectList());

					StudentInfo stdInfo = (StudentInfo) session.getAttribute("stdInfo");

					// 로그인 후 메인화면에 올 때,
					// 수강/강의중인 강의 정보를 갖고온다.
					SubjectInfoDao subjectInfoDao = (SubjectInfoDao) sc.getAttribute("subjectInfoDao");
					SubjectInfo subjectInfo = subjectInfoDao.getSubjInfo(stdInfo);
					session.setAttribute("subjectInfo", subjectInfo);
					

					response.setContentType("text/html; charset=UTF-8");
					RequestDispatcher rd = request.getRequestDispatcher(
							"/stu_main.jsp");
					rd.forward(request, response);

				}else if(auth.getAuth().equals("professor")) {

					ProfessorInfoDao profInfoDao = (ProfessorInfoDao)sc.getAttribute("proInfoDao");
					//				request.setAttribute("proInfoDao", proInfoDao.selectList());

					ProfessorInfo profInfo = (ProfessorInfo) session.getAttribute("profInfo");

					// 로그인 후 메인화면에 올 때,
					// 수강/강의중인 강의 정보를 갖고온다.
					SubjectInfoDao subjectInfoDao = (SubjectInfoDao) sc.getAttribute("subjectInfoDao");
					SubjectInfo subjectInfo = subjectInfoDao.getSubjInfo(profInfo);
					session.setAttribute("subjectInfo", subjectInfo);
					

					response.setContentType("text/html; charset=UTF-8");
					RequestDispatcher rd = request.getRequestDispatcher(
							"/pr_main.jsp");
					rd.forward(request, response);
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("error", e);
			RequestDispatcher rd = request.getRequestDispatcher("/Error.jsp");
			rd.forward(request, response);
		}
	}
}
