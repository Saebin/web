package servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.ProfessorInfoDao;
import dao.StudentInfoDao;
import dao.SubjectInfoDao;
import vo.Auth;
import vo.ProfessorInfo;
import vo.StudentInfo;
import vo.SubjectInfo;

@WebServlet("/subjectCreate")
public class SubjectCreateServlet extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(
			HttpServletRequest request, HttpServletResponse response)
					throws ServletException, IOException {

		//		RequestDispatcher rd = request.getRequestDispatcher(
		//				"/pro_create_subject.jsp");
		//		rd.forward(request, response);
	}

	@Override
	protected void doPost(
			HttpServletRequest request, HttpServletResponse response)
					throws ServletException, IOException {


		try {
			ServletContext sc = this.getServletContext();

			HttpSession session = request.getSession();
			Auth getAuth = (Auth) session.getAttribute("auth");
			String auth =getAuth.getAuth();

			if(auth.equals("professor")) {
				SubjectInfoDao subjectInfoDao = (SubjectInfoDao) sc.getAttribute("subjectInfoDao");
				subjectInfoDao.insert(
						new SubjectInfo().setSubj_code_div(request.getParameter(""))
										 .setSubj_name(request.getParameter(""))
										 .setSubj_outline(request.getParameter(""))
										 .setSubj_image(request.getParameter(""))
										 .setLimit_num(Integer.parseInt(request.getParameter("")))
										 .setRegist_code(request.getParameter(""))
						);
				
				RequestDispatcher rd = request.getRequestDispatcher(".jsp");
				rd.forward(request, response);
			} else {
				//// 
			}

		} catch (Exception e) {
			throw new ServletException(e);

		}


	}
}
