$(function(){
	$(".content_Notify").hide();
	$(".detail_Notify").click(function(){
		var state = $('.content_Notify').css('display');
        if(state == 'none'){ 
        	$(".content_Notify").show(); 
        }else{ 
        	$(".content_Notify").hide();      
        }
		
	})
	
});


