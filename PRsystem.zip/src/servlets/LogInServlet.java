package servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.AuthDao;
import dao.ProfessorInfoDao;
import dao.StudentInfoDao;
import vo.Auth;
import vo.ProfessorInfo;
import vo.StudentInfo;

// ServletContext에 보관된 MemberDao 사용하기  
@WebServlet("/login")
public class LogInServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(
			HttpServletRequest request, HttpServletResponse response)
					throws ServletException, IOException {
		RequestDispatcher rd = request.getRequestDispatcher(
				"/Login.jsp");
		rd.forward(request, response);
	}

	@Override
	protected void doPost(
			HttpServletRequest request, HttpServletResponse response)
					throws ServletException, IOException {
		try {
			ServletContext sc = this.getServletContext();

			AuthDao authDao = (AuthDao) sc.getAttribute("authDao");
			Auth auth = authDao.existAuth( request.getParameter("email"), request.getParameter("password"));	

			if(auth.getAuth().equals("student")) {
				
				HttpSession session = request.getSession();
				session.setAttribute("auth", auth);
				
				StudentInfoDao stdInfoDao = (StudentInfoDao) sc.getAttribute("stdInfoDao");
			
				StudentInfo stdInfo = stdInfoDao.exist(
						request.getParameter("email"), 
						request.getParameter("password"));

				if (stdInfo != null) {
					session.setAttribute("stdInfo", stdInfo);
					response.sendRedirect("main");
					
				} else {
					RequestDispatcher rd = request.getRequestDispatcher(
							"/auth/LogInFail.jsp");
					rd.forward(request, response);
				}
				
			} else if(auth.getAuth().equals("professor")) {
				
				HttpSession session = request.getSession();
				session.setAttribute("auth", auth);
				
				ProfessorInfoDao profInfoDao = (ProfessorInfoDao) sc.getAttribute("profInfoDao");

				ProfessorInfo profInfo = profInfoDao.exist(
						request.getParameter("email"), 
						request.getParameter("password"));

				if (profInfo != null) {
					session.setAttribute("profInfo", profInfo);
					response.sendRedirect("main");

				} else {
					RequestDispatcher rd = request.getRequestDispatcher(
							"/auth/LogInFail.jsp");
					rd.forward(request, response);
				}
			}

		} catch (Exception e) {
			throw new ServletException(e);

		}


	}
}
