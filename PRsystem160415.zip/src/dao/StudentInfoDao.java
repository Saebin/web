package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.sql.DataSource;

import vo.Member;
import vo.StudentInfo;

public class StudentInfoDao {

	DataSource ds;

	public void setDataSource(DataSource ds) {
		this.ds = ds;
	}

	public int insert(StudentInfo stdInfo) throws Exception  {
		Connection connection = null;
		PreparedStatement stmt = null;

		try {
			connection = ds.getConnection();
			stmt = connection.prepareStatement(
					"INSERT INTO STUDENT_INFO(STD_ID,STD_NAME,STD_PWD,STD_EMAIL,STD_PHONE,STD_AUTH,STD_CRE_DATE,STD_MOD_DATE)"
							+ " VALUES (?,?,?,?,?,?,NOW(),NOW())");
			stmt.setInt(1, stdInfo.getStdId());
			stmt.setString(2, stdInfo.getStdName());
			stmt.setString(3, stdInfo.getStdPwd());
			stmt.setString(4, stdInfo.getStdEmail());
			stmt.setString(5, stdInfo.getStdPhone());
			stmt.setString(6, stdInfo.getStdAuth());
			return stmt.executeUpdate();

		} catch (Exception e) {
			throw e;

		} finally {
			try {if (stmt != null) stmt.close();} catch(Exception e) {}
			try {if (connection != null) connection.close();} catch(Exception e) {}
		}
	}
	
	//로그인 후, 세션에 담을 객체 생성 ( 이메일, 이름, 권한 ,학번)
	public StudentInfo exist(String email, String password) throws Exception {
		Connection connection = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;

		try {
			connection = ds.getConnection();
			stmt = connection.prepareStatement(
					"SELECT STD_EMAIL,STD_NAME,STD_AUTH,STD_ID FROM STUDENT_INFO"
							+ " WHERE STD_EMAIL=? AND STD_PWD=?");
			stmt.setString(1, email);
			stmt.setString(2, password);
			rs = stmt.executeQuery();
			if (rs.next()) {
				return new StudentInfo()
						.setStdName(rs.getString("STD_EMAIL"))
						.setStdEmail(rs.getString("STD_NAME"))
						.setStdEmail(rs.getString("STD_AUTH"))
						.setStdEmail(rs.getString("STD_ID"));
			} else {
				return null;
			}
		} catch (Exception e) {
			throw e;

		} finally {
			try {if (rs != null) rs.close();} catch (Exception e) {}
			try {if (stmt != null) stmt.close();} catch (Exception e) {}
			try {if (connection != null) connection.close();} catch(Exception e) {}
		}
	}
}
