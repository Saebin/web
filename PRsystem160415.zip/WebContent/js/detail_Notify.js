$(function(){
	$(".detail_Notify").hide();
	
	$(".detail_Notify a").click(function() {
	    $(this).parent().parent().nextUntil(".detail_Notify").toggle();
	    return false;
	});
	$(".tr_visible a").click(function() {
	    $(this).parent().parent().nextUntil(".tr_visible").toggle();
	    return false;
	});
	
	/*$(".detail_Notify").click(function(){
		var state = $('.content_Notify').css('display');
        if(state == 'none'){ 
        	$(".content_Notify").show(); 
        }else{ 
        	$(".content_Notify").hide();      
        }
		
	})*/
	
});


