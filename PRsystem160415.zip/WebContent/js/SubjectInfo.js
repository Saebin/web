$(document).ready(function() {
	$('li').click(function(){
		alert(this.id);
		$('#task_situation').text("'"+this.id+"'"+"과제 현황");
	});
});